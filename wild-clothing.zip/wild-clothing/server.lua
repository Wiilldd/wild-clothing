HT = nil

TriggerEvent('HT_base:getBaseObjects', function(obj) HT = obj end)

local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")

vRPclient = Tunnel.getInterface("vRP", "dit_script") 
vRP = Proxy.getInterface("vRP")

RegisterServerEvent('raid_clothes:save')
AddEventHandler('raid_clothes:save', function(data)
	local user_id = vRP.getUserId({source})

	MySQL.Async.execute('UPDATE vrp_user_identities SET `skin` = @data WHERE user_id = @user_id',
	{
		['@data']       = json.encode(data),
		['@user_id'] = user_id
	})
end)

--[[AddEventHandler("vRP:playerSpawn",function(user_id,source,first_spawn)
		local source = source
		local user_id = vRP.getUserId({source})
		TriggerClientEvent('raid_clothes:LoadPlayerSkin', user_id)

end)]]--

RegisterServerEvent('raid_clothes:loadclothes')
AddEventHandler('raid_clothes:loadclothes', function()
	local user_id = vRP.getUserId({source})

	MySQL.Async.fetchAll('SELECT * FROM vrp_user_identities WHERE user_id = @user_id', {
		['@user_id'] = user_id
	}, function(users)
		local user = users[1]
		local skin = nil

		if user.skin ~= nil then
			skin = json.decode(user.skin)
		end

		TriggerClientEvent('raid_clothes:loadclothes', skin)
	end)


end)

HT.RegisterServerCallback('raid_clothes:getPlayerSkin', function(source, cb)
	local user_id = vRP.getUserId({source})

	MySQL.Async.fetchAll('SELECT * FROM vrp_user_identities WHERE user_id = @user_id', {
		['@user_id'] = user_id
	}, function(users)
		local user = users[1]
		local skin = nil


		if user.skin ~= nil then
			skin = json.decode(user.skin)
		end

		cb(skin)
	end)
end)
